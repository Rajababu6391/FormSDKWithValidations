//
//  PageThreeViewController.swift
//  consumer3
//
//  Created by Rajababu on 21/07/20.
//  Copyright © 2020 Rajababu Thummala. All rights reserved.
//

import UIKit

class PageThreeViewController: UIViewController {
    
    var errorTextField : UITextField = UITextField()
    var dataDict1 : [String:String] = [String:String]()
    var dataDict2 : [String:String] = [String:String]()
    var dataDict3 : [String:String] = [String:String]()
    
    
    @IBOutlet weak var teamsizeTxtField: UITextField!
    @IBOutlet weak var desTxtField: UITextField!
    @IBOutlet weak var durationTxtField: UITextField!
    @IBOutlet weak var usedTechTxtField: UITextField!
    @IBOutlet weak var proojectnameTxtField: UITextField!
    @IBAction func submitBtnTapped(_ sender: Any) {
        var ErrorMessage : String?
               //--------------validation of textfields------------
               if proojectnameTxtField.text == "" {
                   ErrorMessage = "required information"
                   errorTextField = proojectnameTxtField!
               } else if usedTechTxtField.text == ""{
                   ErrorMessage = "required information"
                   errorTextField = usedTechTxtField!
               }else if durationTxtField.text == ""{
                    ErrorMessage = "required information"
                    errorTextField = durationTxtField!
               }else if desTxtField.text == ""{
                    ErrorMessage = "Required information"
                    errorTextField = desTxtField!
                }
                else if teamsizeTxtField.text == ""{
                    ErrorMessage = "Required information"
                    errorTextField = teamsizeTxtField!
                }

               if ErrorMessage?.range(of: ErrorMessage!) != nil  {
                let alertController = UIAlertController(title: "Form", message: ErrorMessage, preferredStyle:UIAlertController.Style.alert)
                let defaultAction = UIAlertAction(title: "OK", style:UIAlertAction.Style.default, handler: nil)
                   alertController.addAction(defaultAction)
                   self.present(alertController, animated: true, completion: nil)
               }else{
                print("Next clicked")
                
                var form1jsonString:String?
                var form2jsonString:String?
                var form3jsonString:String?
                dataDict3 = ["projectname":proojectnameTxtField.text!,"duration":durationTxtField.text!,"technology":usedTechTxtField.text!,"description":desTxtField.text!,"teamsize":teamsizeTxtField.text!]
                
        form1jsonString = convertDictionaryTOJson(dict: dataDict1)
        form2jsonString = convertDictionaryTOJson(dict: dataDict2)
        form3jsonString = convertDictionaryTOJson(dict: dataDict3)
        form1jsonString?.append(form2jsonString!)
                form1jsonString?.append(form3jsonString!)
                print("final json String....display data:",form1jsonString!)
        }
        
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "FORM3"


        // Do any additional setup after loading the view.
    }
    
    func convertDictionaryTOJson(dict:[String:String])->String{
        var returnstr : String?
        
        if let theJSONData = try?  JSONSerialization.data(
          withJSONObject: dict,
          options: .prettyPrinted
          ),
          let form2JSONText = String(data: theJSONData,
                                   encoding: String.Encoding.ascii) {
              print("form1JSONText JSON string = \n\(form2JSONText)")
            returnstr = form2JSONText
        }
        return returnstr!
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
