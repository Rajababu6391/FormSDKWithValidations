//
//  Rules.swift
//  consumer3
//
//  Created by Rajababu Thummala on 21/07/20.
//  Copyright © 2020 Rajababu Thummala. All rights reserved.
//

import Foundation



class Rules : NSObject{

    var email : String
    var max : String
    var min : String


    /**
     * Instantiate the instance using the passed dictionary values to set the properties values
     */
    init(fromDictionary dictionary: [String:Any]){
        email = dictionary["email"] as? String ?? ""
        max = dictionary["max"] as? String ?? ""
        min = dictionary["min"] as? String ?? ""
    }
}
