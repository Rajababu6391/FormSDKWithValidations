//
//  ViewController.swift
//  consumer3
//
//  Created by Rajababu Thummala on 20/07/20.
//  Copyright © 2020 Rajababu Thummala. All rights reserved.
//

import UIKit
import Validations1

class ViewController: UIViewController {
    var errorTextField : UITextField!
    var dict : [String:String] = [String:String]()
    var rules:Rules?
    let validation:Validations = Validations()
    var strEmail : String?

    @IBOutlet weak var positionTxtField: UITextField!
    @IBOutlet weak var dateTxtField: UITextField!
    @IBOutlet weak var emailTxtField: UITextField!
    @IBOutlet weak var addressTxtField: UITextField!
    @IBOutlet weak var lastNameTxtField: UITextField!
    @IBOutlet weak var firstNameTxtField: UITextField!
    @IBOutlet weak var NextBtn: UIButton!
    @IBAction func NextBtnTapped(_ sender: Any) {
        
        var ErrorMessage : String?
               //--------------validation of textfields------------
               if firstNameTxtField.text == "" {
                   ErrorMessage = "please enter firstName"
                   errorTextField = firstNameTxtField!
                
               } else if lastNameTxtField.text == ""{
                   ErrorMessage = "please enter lastName"
                   errorTextField = lastNameTxtField!
               }else if addressTxtField.text == ""{
                    ErrorMessage = "please enter address"
                    errorTextField = addressTxtField!
               }else if emailTxtField.text == ""{
                    ErrorMessage = "please your enter email"
                    errorTextField = addressTxtField!
                }else if dateTxtField.text == ""{
                    ErrorMessage = "please enter date Available"
                    errorTextField = dateTxtField!
                }else if positionTxtField.text == ""{
                    ErrorMessage = "please enter position"
                    errorTextField = positionTxtField!
               }else if validation.validate(emailTxtField.text!, regex: rules!.email) == false{
                
                ErrorMessage = "please enter valid email"
                errorTextField = positionTxtField!
                
                }
        
        if validation.validate(emailTxtField.text!, regex: rules!.email) == true{
            print("validate email",emailTxtField.text!)
            
        }else{
            print("Invalid email",emailTxtField.text!)

        }
        

               if ErrorMessage?.range(of: ErrorMessage!) != nil  {
                let alertController = UIAlertController(title: "Form", message: ErrorMessage, preferredStyle:UIAlertController.Style.alert)
                let defaultAction = UIAlertAction(title: "OK", style:UIAlertAction.Style.default, handler: nil)
                   alertController.addAction(defaultAction)
                   self.present(alertController, animated: true, completion: nil)
               }else{
                    print("Next clicked")
                let appDelegate = UIApplication.shared.delegate as! AppDelegate
                
                
                if validation.validate(emailTxtField.text!, regex: rules!.email) == true{
                    print("validate email",emailTxtField.text!)
                    
                }else{
                    print("Invalid email",emailTxtField.text!)

                }

                
                dict = ["firstname":firstNameTxtField.text!,"lastname":lastNameTxtField.text!,"adress":addressTxtField.text!,"email":emailTxtField.text!,"date":dateTxtField.text!,"position":positionTxtField.text!
                ]
                
                let storyVC = UIStoryboard.init(name: "Main", bundle: nil)
                  let vc1 = storyVC.instantiateViewController(identifier: "PageTwoViewController") as PageTwoViewController
                vc1.secondpageDict = dict
                  self.navigationController?.pushViewController(vc1, animated: true)
            
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        print("viewController1")
        self.title = "FORM"
        if let path = Bundle.main.path(forResource: "validationRules", ofType: "json") {
            do {
                  let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                  let jsonResult = try JSONSerialization.jsonObject(with: data, options: .mutableLeaves)
                  if let jsonResult = jsonResult as? Dictionary<String, AnyObject> {
                    rules = Rules.init(fromDictionary: jsonResult)
                    
                    print(validation.validate("asdasd123123@asd.com", regex: rules!.email))
                    print(validation.validate("12345", regex: rules!.min))
                    print(validation.validate("12345sacafafadfafafsca", regex: rules!.max))
                  }
              } catch {
              }
        }
        // Do any additional setup after loading the view.
    }


}

