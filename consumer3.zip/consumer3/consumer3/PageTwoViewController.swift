//
//  PageTwoViewController.swift
//  consumer3
//
//  Created by Rajababu on 21/07/20.
//  Copyright © 2020 Rajababu Thummala. All rights reserved.
//

import UIKit
import Foundation

class PageTwoViewController: UIViewController {
    var errorTextField : UITextField!
    var secondpageDict : [String:String] = [String:String]()
    var dataDict : [String:String] = [String:String]()
    var language1 : String?
    var language2 : String?
    var language3 : String?
    var language4 : String?


    @IBOutlet weak var kotlinBtn: UIButton!
    @IBOutlet weak var javaBtn: UIButton!
    @IBOutlet weak var swiftBtn: UIButton!
    @IBOutlet weak var objectiveCBtn: UIButton!
    @IBOutlet weak var pgTxtField: UITextField!
    @IBOutlet weak var ugTxtField: UITextField!
    @IBOutlet weak var intermediateTxtField: UITextField!
    @IBOutlet weak var sscTxtField: UITextField!
    @IBOutlet weak var NextBtn: UIButton!

    @IBAction func kotlinBtnTapped(_ sender: Any) {
        if self.kotlinBtn.isSelected == true{
            kotlinBtn.isSelected = false
            language4 = "Kotlin"
            
        }else{
            
            kotlinBtn.isSelected = true
        }
    }
    @IBAction func javaBtnTapped(_ sender: Any) {
        if self.javaBtn.isSelected == true{
            javaBtn.isSelected = false
            language3 = "JAVA"

        }else{
            
            javaBtn.isSelected = true
        }
    }
    @IBAction func swiftBtnTapped(_ sender: Any) {
        if self.swiftBtn.isSelected == true{
            swiftBtn.isSelected = false
            language2 = "Swift"

        }else{
            swiftBtn.isSelected = true
        }
    }
    @IBAction func objectiveCBtnTapped(_ sender: Any) {
        
        if self.objectiveCBtn.isSelected == true{
            objectiveCBtn.isSelected = false
            language1 = "Objective-C"
            
        }else{
            objectiveCBtn.isSelected = true
        }
        
    }
    @IBAction func NextBtnTapped(_ sender: Any) {
        var ErrorMessage : String?
               //--------------validation of textfields------------
               if sscTxtField.text == "" {
                   ErrorMessage = "required ssc percentage"
                   errorTextField = sscTxtField!
               } else if intermediateTxtField.text == ""{
                   ErrorMessage = "required inter percentage"
                   errorTextField = intermediateTxtField!
               }else if ugTxtField.text == ""{
                    ErrorMessage = "required ug percentage"
                    errorTextField = ugTxtField!
               }else if pgTxtField.text == ""{
                    ErrorMessage = "Required pg percentage"
                    errorTextField = pgTxtField!
               }else if language1 == "",language2 == "",language3 == "",language4 == ""{
                    ErrorMessage = "Required language"

                }

               if ErrorMessage?.range(of: ErrorMessage!) != nil  {
                let alertController = UIAlertController(title: "Form", message: ErrorMessage, preferredStyle:UIAlertController.Style.alert)
                let defaultAction = UIAlertAction(title: "OK", style:UIAlertAction.Style.default, handler: nil)
                   alertController.addAction(defaultAction)
                   self.present(alertController, animated: true, completion: nil)
               }else{
                print("Next clicked")
                let appDelegate = UIApplication.shared.delegate as! AppDelegate
                guard let lan1 = language1, let lan2 = language2, let lan3 = language3, let lan4 = language4 else {
                    return
                }
                dataDict = ["ssc":sscTxtField.text!,"intermediate":intermediateTxtField.text!,"ug":ugTxtField.text!,"pg":pgTxtField.text!]
                
                
                
                let storyVC = UIStoryboard.init(name: "Main", bundle: nil)
                
                let vc1 = storyVC.instantiateViewController(identifier: "PageThreeViewController") as PageThreeViewController
                
                vc1.dataDict2 = dataDict
                vc1.dataDict1 = secondpageDict

               
                

                self.navigationController?.pushViewController(vc1, animated: true)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "FORM2"

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
