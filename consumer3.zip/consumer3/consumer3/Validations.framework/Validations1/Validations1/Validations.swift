//
//  Validations.swift
//  Validations
//
//  Created by Rajababu Thummala on 20/07/20.
//  Copyright © 2020 Rajababu Thummala. All rights reserved.
//

import Foundation
import UIKit

public class Validations {
    public init(){}
    
    public func validate(_ input: String, regex: String) -> Bool {
        return NSPredicate(format: "SELF MATCHES %@", regex).evaluate(with: input)
    }
    
    public func required(_ input: String) -> Bool {
        return input.isEmpty
    }
}
